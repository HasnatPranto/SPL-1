//
// Created by Pranto on 9/12/2019.
//

#ifndef REFERENCEMAPPER_MAPPER_H
#define REFERENCEMAPPER_MAPPER_H

int doMapping();

#endif //REFERENCEMAPPER_MAPPER_H
