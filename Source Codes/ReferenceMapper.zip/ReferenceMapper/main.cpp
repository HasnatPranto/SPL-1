#include <iostream>
#include "mapper.h"
#include "parser.h"
#define SHELLSCRIPT "\
#/bin/bash \n\
java -jar /home/pranto/Desktop/ReferenceMapper/papers/jar/pdt0.jar"

using namespace std;

int main()
{
    int sw=0;

    cout << "**********Reference Mapper*************\n";

    while(sw!=4)
    {
        cout << "\n1.PDF to Text Conversion using JAR\n2.Parse Text Files into XML\n3.Map References of Authors\n4.Exit\nEnter Your Choice: ";
        cin >> sw;

        switch(sw)
        {
            case 1: system(SHELLSCRIPT);
                    cout << "\nPDF to Text Conversion Successful\n";
                    break;
            case 2: doParsing();
                    break;
            case 3: doMapping();
                    break;
            case 4: break;

        }


    }

    return 0;
}
