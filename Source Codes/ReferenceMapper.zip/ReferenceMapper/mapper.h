#ifndef MAPPER_H_INCLUDED
#define MAPPER_H_INCLUDED

int doMapping();

#endif // MAPPER_H_INCLUDED
